const imagenes = document.querySelectorAll('.item');
const btnDerecha = document.getElementById('btn-der');
const btnIzquierda = document.getElementById('btn-izq');

let indice = 0;

function mostrarImagen() {
  imagenes.forEach(img => img.classList.remove('activo'));
  imagenes[indice].classList.add('activo');
}

// Botón derecha
btnDerecha.addEventListener('click', () => {
  indice = (indice + 1) % imagenes.length;
  mostrarImagen();
});

// Botón izquierda
btnIzquierda.addEventListener('click', () => {
  indice = (indice - 1 + imagenes.length) % imagenes.length;
  mostrarImagen();
});
