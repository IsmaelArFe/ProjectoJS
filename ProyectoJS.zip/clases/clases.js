const fs = require('fs');

class Usuario {
  constructor(nombre, apellidos, email, password, administrador = false) {
    this.nombre = nombre;
    this.apellidos = apellidos;
    this.email = email;
    this.password = password;
    this.administrador = administrador;
  }
}

class GestorUsuarios {
  constructor(rutaArchivo = './json/usuarios.json') {
    this.rutaArchivo = rutaArchivo;
  }

  obtenerUsuarios() {
    try {
      const data = fs.readFileSync(this.rutaArchivo, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      return [];
    }
  }

  crearUsuario(usuario) {
    const usuarios = this.obtenerUsuarios();

    const existe = usuarios.find(u => u.email === usuario.email);
    if (existe) {
      throw new Error('El correo ya está registrado');
    }

    usuarios.push(usuario);
    fs.writeFileSync(this.rutaArchivo, JSON.stringify(usuarios, null, 2));
  }
}

module.exports = { Usuario, GestorUsuarios };

class Viajes {
  constructor(id, fechaIni, fechaFin , cohete, destino) {
    this.id = id;
    this.fechaIni = fechaIni;
    this.calse = fechaFin;
    this.fechaFin = fechaFin;
    this.cohete = cohete;
    this.destino = destino;
  }
}

class Planeta {
  constructor(nombre, distancia, foto,tamaño,descripcion_corta, precio, descripcion_larga ,hotel) {
    this.nombre = nombre;
    this.distancia = distancia;
    this.foto = foto;
    this.tamaño = tamaño;
    this.precio = precio;
    this.descripcion_corta = descripcion_corta
    this.descripcion_larga = descripcion_larga
    this.hotel = hotel;
  }
}
