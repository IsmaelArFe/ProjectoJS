class Usuario {
  constructor(nombre, apellidos, email, password, administrador) {
    this.nombre = nombre;
    this.apellidos = apellidos;
    this.email = email;
    this.password = password;
    this.administrador = administrador;
  }
}

class Cohete {
  constructor(nombre, capacidad, foto , calse, combustible, velocidadMax) {
    this.nombre = nombre;
    this.capacidad = capacidad;
    this.calse = calse;
    this.foto = foto;
    this.combustible = combustible;
    this.velocidadMax = velocidadMax;
  }
}

class Planeta {
  constructor(nombre, distancia, tamaño, habitable, hotel) {
    this.nombre = nombre;
    this.distancia = distancia;
    this.tamaño = tamaño;
    this.habitable = habitable;
    this.hotel = hotel;
  }
}