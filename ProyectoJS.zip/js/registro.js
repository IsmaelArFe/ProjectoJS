onload = () => {
  document.getElementById("register-button").addEventListener("click", registro);
};

async function registro(e) {
  e.preventDefault(); // evita recarga si es botón submit o dentro de form

  const nombre = document.getElementById("register-nombre").value.trim();
  const apellidos = document.getElementById("register-apellidos").value.trim();
  const email = document.getElementById("register-email").value.trim().toLowerCase();
  const password = document.getElementById("register-password").value.trim();
  const errorMsg = document.getElementById('registro-error');

  try {
    let data = JSON.parse(localStorage.getItem("usuarios") || "null");

    if (!Array.isArray(data)) {
      const res = await fetch('../json/usuarios.json', { cache: 'no-store' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      data = await res.json();
    }

    const existe = data.some(u => (u.email || '').toLowerCase() === email);
    if (existe) {
      errorMsg.textContent = 'El correo ya está registrado';
      errorMsg.style.display = 'block';
      return;
    }

    errorMsg.style.display = 'none';

    // 👇 usa el MISMO esquema que en el JSON y el login
    const nuevoUsuario = { nombre, apellidos, email, password, administrador: false };

    data.push(nuevoUsuario);
    localStorage.setItem("usuarios", JSON.stringify(data));

    // redirige al login
    window.location.href = "./login.html";
  } catch (err) {
    console.error('Error al leer el JSON:', err);
    errorMsg.textContent = 'Error al cargar datos';
    errorMsg.style.display = 'block';
  }
}
