onload = () => {
    escribirTexto();
    carrusel();
    document.getElementById("menu").addEventListener("click", () => abrirMenu("Sidenav"));
    document.getElementById("Sidenav").addEventListener("mouseleave",() =>  cerrarMenu("Sidenav"));
    document.getElementById("login").addEventListener("click", () => abrirMenu("Usuario"));
    document.getElementById("Usuario").addEventListener("mouseleave", () =>  cerrarMenu("Usuario"));
}

function abrirMenu(menu){
    document.getElementById(menu).style.width = "250px";
}
function cerrarMenu(menu){
    document.getElementById(menu).style.width = "0px";
}

function escribirTexto() {
    let texto1 = "SpaceExplorer";
    let salida1 = document.getElementById("txt-principal");
    let i = 0;
    let intervalo =setInterval(() => {
        if (i < texto1.length) {
            salida1.innerHTML += texto1[i];
            i++;
        }else{
            clearInterval(intervalo);
            escribirPalabras();
        }
    }, 150);
}
function escribirPalabras() {
    let texto = `Más allá del cielo, el espacio te espera. <br> Lo que antes fue un sueño, hoy es tu próximo destino`;
    let salida = document.getElementById("txt-sec");
    let i = 0;
    let palabras = texto.split(" ");
    let intervalo = setInterval(() => {
        if (i < palabras.length) {
            salida.innerHTML += palabras[i] + " " ;
            i++;
        }else{
            clearInterval(intervalo);
        }
    }, 100);
}

function carrusel() {
  const items = document.querySelectorAll(".item");
  const btnIzq = document.getElementById("btn-izq");
  const btnDer = document.getElementById("btn-der");
  let indice = 0;

  function actualizarCarrusel() {
    items.forEach((item, i) => {
      item.classList.remove("activo");
      

      let separacion = (i - indice) * 700; 
      
      item.style.left = `calc(50% + ${separacion}px)`;
      item.style.opacity = (i === indice) ? "1" : "0.3";
      item.style.transform = (i === indice)
        ? "translate(-50%, -50%) scale(1.2)"
        : "translate(-50%, -50%) scale(0.8)";
    });

    items[indice].classList.add("activo");
  }

  btnDer.addEventListener("click", () => {
    indice = (indice + 1) % items.length;
    actualizarCarrusel();
  });

  btnIzq.addEventListener("click", () => {
    indice = (indice - 1 + items.length) % items.length;
    actualizarCarrusel();
  });

  actualizarCarrusel();
}

