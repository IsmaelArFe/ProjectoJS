onload = async () => {
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault(); // evita recarga del formulario

    const email = document.getElementById("login-email").value.trim().toLowerCase();
    const password = document.getElementById("login-password").value.trim();
    const errorMsg = document.getElementById('login-error');

    // Validación básica
    if (!email || !password) {
      errorMsg.textContent = 'Rellena email y contraseña';
      errorMsg.style.display = 'block';
      return;
    }

    try {
      // 1️⃣ Buscar primero en localStorage
      let usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]");
      let usuario = null;

      // Buscar coincidencia en localStorage
      for (let u of usuarios) {
        if (u.email && u.email.toLowerCase() === email && u.password === password) {
          usuario = u;
          break;
        }
      }

      // 2️⃣ Si no está en localStorage, buscar en JSON
      if (!usuario) {
        const res = await fetch('../json/usuarios.json', { cache: 'no-store' });
        if (!res.ok) throw new Error(`Error HTTP ${res.status}`);

        const data = await res.json();

        for (let u of data) {
          if (u.email && u.email.toLowerCase() === email && u.password === password) {
            usuario = u;
            break;
          }
        }
      }

      // 3️⃣ Validar resultado
      if (usuario) {
        errorMsg.style.display = 'none';

        // Guardar sesión
        localStorage.setItem("usuarioActivo", JSON.stringify({
          email: usuario.email,
          nombre: usuario.nombre,
          administrador: !!usuario.administrador
        }));

        // Redirigir según tipo de usuario
        if (usuario.administrador) {
          window.location.href = "../html/admin.html";
        } else {
          window.location.href = "../html/Index.html";
        }

      } else {
        errorMsg.textContent = 'Email o contraseña incorrectos';
        errorMsg.style.display = 'block';
      }

    } catch (error) {
      console.error('Error al leer datos:', error);
      errorMsg.textContent = 'Error al cargar datos';
      errorMsg.style.display = 'block';
    }
  });
};
